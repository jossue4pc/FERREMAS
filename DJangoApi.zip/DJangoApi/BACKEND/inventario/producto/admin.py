from django.contrib import admin
from producto.models import producto

admin.site.register(producto)


# Register your models here.
