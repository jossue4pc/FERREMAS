from rest_framework import DefaultRouter
from producto.api.views import ProductoViewSet

router= DefaultRouter()
router.register('producto', ProductoViewSet, basename='producto')
urlpatterns = router.urls
